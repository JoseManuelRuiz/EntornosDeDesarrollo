public class Punto {

    private int id;
    private int x;
    private int y;

    public Punto(){
        x = 0;
        y = 0;
        id = 0;
    }

    public Punto(int id, int x, int y){
        this.x = x;
        this.y = y;
        this.id = id;
    }
}
